import {StyleSheet} from 'react-native'

export default StyleSheet.create({
    container: {
      backgroundColor: 'Blue',
    },
    nome: {
    fontWeight: '700',
    color:'red',
    justifyContent:'center',
    textAlign: 'center',
    marginTop: 290
  },
  idade: {
    fontWeight: '700',
    color:'red',
    justifyContent:'center',
    textAlign: 'center',
  },
  cargo: {
    fontWeight: '700',
    color:'red',
    justifyContent:'center',
    textAlign: 'center',
  }
});