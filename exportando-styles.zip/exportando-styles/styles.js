import {StyleSheet} from 'react-native';

export default StyleSheet.create({
  frontEnd: {
    flex:1,
    backgroundColor: '#f5f5f5',
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#4432DB',
  },
  button: {
    backgroundColor: '#6309DB',
    padding: 10,
    borderRadius: 8,
    marginTop: 15,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
  },
});

