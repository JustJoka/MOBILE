export default function saudacao (nome){
  return `Olá, ${nome}`;
}

export function toUpper(texto){
 return texto.toUpperCase();
}

export function toLower(texto){
  return texto.toLowerCase();
}
